package com.zybooks.weightnotwanted;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

// db Schema
public class SQLiteModule extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "appDatabase.db";
    private static final int DATABASE_VERSION = 3;

    public static final String TABLE_USERS = "users";
    public static final String TABLE_WEIGHT_DATA = "weight_data";

    public static final String COLUMN_ID = "id";
    public static final String COLUMN_USER_ID = "user_id";
    public static final String COLUMN_USERNAME = "username";
    public static final String COLUMN_PASSWORD = "password";
    public static final String COLUMN_DATE = "date";
    public static final String COLUMN_CURRENT_WEIGHT = "current_weight";
    public static final String COLUMN_GOAL_WEIGHT = "goal_weight";
    public static final String COLUMN_DATE_SET = "date_set";

    public SQLiteModule(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_USERS_TABLE = "CREATE TABLE " + TABLE_USERS + " (" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_USERNAME + " TEXT, " +
                COLUMN_PASSWORD + " TEXT);";
        db.execSQL(CREATE_USERS_TABLE);

        String CREATE_WEIGHT_DATA_TABLE = "CREATE TABLE " + TABLE_WEIGHT_DATA + " (" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_USER_ID + " INTEGER, " +
                COLUMN_DATE + " TEXT, " +
                COLUMN_CURRENT_WEIGHT + " REAL, " +
                COLUMN_GOAL_WEIGHT + " REAL, " +
                COLUMN_DATE_SET + " TEXT, " +
                "FOREIGN KEY(" + COLUMN_USER_ID + ") REFERENCES " + TABLE_USERS + "(" + COLUMN_ID + "));";
        db.execSQL(CREATE_WEIGHT_DATA_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 3) {
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_WEIGHT_DATA);
            onCreate(db);
        }
    }
}

