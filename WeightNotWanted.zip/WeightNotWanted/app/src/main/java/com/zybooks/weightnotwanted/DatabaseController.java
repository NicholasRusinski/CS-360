package com.zybooks.weightnotwanted;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class DatabaseController {

    private SQLiteModule Module;

    public DatabaseController(Context context) {
        Module = new SQLiteModule(context);
    }

    public boolean addUser(String username, String password) {
        SQLiteDatabase db = Module.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(SQLiteModule.COLUMN_USERNAME, username);
        values.put(SQLiteModule.COLUMN_PASSWORD, password);

        long result = db.insert(SQLiteModule.TABLE_USERS, null, values);
        db.close();
        return result != -1;
    }

    public int checkUser(String username, String password) {
        SQLiteDatabase db = Module.getReadableDatabase();
        String[] columns = {SQLiteModule.COLUMN_ID, SQLiteModule.COLUMN_USERNAME, SQLiteModule.COLUMN_PASSWORD};
        String selection = SQLiteModule.COLUMN_USERNAME + " = ? AND " + SQLiteModule.COLUMN_PASSWORD + " = ?";
        String[] selectionArgs = {username, password};

        Cursor cursor = db.query(SQLiteModule.TABLE_USERS, columns, selection, selectionArgs, null, null, null);

        if (cursor != null && cursor.moveToFirst()) {
            int userId = cursor.getInt(cursor.getColumnIndex(SQLiteModule.COLUMN_ID));
            cursor.close();
            db.close();
            return userId;
        }

        cursor.close();
        db.close();
        return -1;
    }

    public boolean addWeightData(int userId, String date, float currentWeight, float goalWeight) {
        SQLiteDatabase db = Module.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(SQLiteModule.COLUMN_USER_ID, userId);
        values.put(SQLiteModule.COLUMN_DATE, date);
        values.put(SQLiteModule.COLUMN_CURRENT_WEIGHT, currentWeight);
        values.put(SQLiteModule.COLUMN_GOAL_WEIGHT, goalWeight);

        long result = db.insert(SQLiteModule.TABLE_WEIGHT_DATA, null, values);
        db.close();
        return result != -1;
    }

    public Cursor getWeightData(int userId) {
        SQLiteDatabase db = Module.getReadableDatabase();
        String query = "SELECT * FROM " + SQLiteModule.TABLE_WEIGHT_DATA +
                " WHERE " + SQLiteModule.COLUMN_USER_ID + " = ?" +
                " ORDER BY " + SQLiteModule.COLUMN_DATE + " ASC";
        return db.rawQuery(query, new String[]{String.valueOf(userId)});
    }

    public float getLastGoalWeight(int userId) {
        SQLiteDatabase db = Module.getReadableDatabase();
        String query = "SELECT " + SQLiteModule.COLUMN_GOAL_WEIGHT + " FROM " + SQLiteModule.TABLE_WEIGHT_DATA +
                " WHERE " + SQLiteModule.COLUMN_USER_ID + " = ?" +
                " ORDER BY " + SQLiteModule.COLUMN_DATE + " DESC LIMIT 1";
        Cursor cursor = db.rawQuery(query, new String[]{String.valueOf(userId)});

        float goalWeight = 0;
        if (cursor != null && cursor.moveToFirst()) {
            goalWeight = cursor.getFloat(cursor.getColumnIndex(SQLiteModule.COLUMN_GOAL_WEIGHT));
            cursor.close();
        }
        db.close();
        return goalWeight;
    }

    public void updateGoalWeight(int userId, float goalWeight) {
        SQLiteDatabase db = Module.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(SQLiteModule.COLUMN_USER_ID, userId);
        contentValues.put(SQLiteModule.COLUMN_GOAL_WEIGHT, goalWeight);
        contentValues.put(SQLiteModule.COLUMN_DATE_SET, getCurrentDate());

        int result = db.update(SQLiteModule.TABLE_WEIGHT_DATA, contentValues, SQLiteModule.COLUMN_USER_ID + " = ?", new String[]{String.valueOf(userId)});
        if (result == 0) {
            db.insert(SQLiteModule.TABLE_WEIGHT_DATA, null, contentValues);
        }
        db.close();
    }

    private String getCurrentDate() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        return sdf.format(new Date());
    }

    public boolean deleteWeightData(int weightDataId) {
        SQLiteDatabase db = Module.getWritableDatabase();
        int rowsAffected = db.delete(SQLiteModule.TABLE_WEIGHT_DATA, SQLiteModule.COLUMN_ID + " = ?", new String[]{String.valueOf(weightDataId)});
        db.close();
        return rowsAffected > 0;
    }
}


