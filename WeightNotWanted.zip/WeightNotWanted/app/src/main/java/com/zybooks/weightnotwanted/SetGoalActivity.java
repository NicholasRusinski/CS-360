package com.zybooks.weightnotwanted;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class SetGoalActivity extends AppCompatActivity {
    private EditText goalWeightEditText;
    private Button saveGoalButton, cancelGoalButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_set_goal);

        goalWeightEditText = findViewById(R.id.goalWeightEditText);
        saveGoalButton = findViewById(R.id.setGoalButton);
        cancelGoalButton = findViewById(R.id.cancelGoalButton);

        saveGoalButton.setOnClickListener(v -> {
            String goalWeightStr = goalWeightEditText.getText().toString();
            if (!goalWeightStr.isEmpty()) {
                float goalWeight = Float.parseFloat(goalWeightStr);
                saveGoalWeightToBuffer(goalWeight);
                Toast.makeText(SetGoalActivity.this, "Goal weight saved to buffer", Toast.LENGTH_SHORT).show();
                finish();
            } else {
                Toast.makeText(SetGoalActivity.this, "Please enter a goal weight", Toast.LENGTH_SHORT).show();
            }
        });

        cancelGoalButton.setOnClickListener(v -> finish());
    }

    // Save goal weight to buffer
    private void saveGoalWeightToBuffer(float goalWeight) {
        SharedPreferences sharedPreferences = getSharedPreferences("UserSession", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putFloat("bufferGoalWeight", goalWeight);
        editor.apply();


        Log.d("GoalWeight", "goal weight saved to buffer: " + goalWeight);
    }
}

