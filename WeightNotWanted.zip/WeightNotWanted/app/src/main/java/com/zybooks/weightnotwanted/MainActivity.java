package com.zybooks.weightnotwanted;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private WeightRecycler weightRecycler;
    private List<WeightData> weightDataList;
    private DatabaseController controller;
    private int userId;

    private Button addDailyWeightButton, setGoalButton, quitButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        SharedPreferences sharedPreferences = getSharedPreferences("UserSession", MODE_PRIVATE);
        userId = sharedPreferences.getInt("userId", -1);

        if (userId == -1) {
            Toast.makeText(this, "Please log in first", Toast.LENGTH_SHORT).show();
            return;
        }

        // Initialize XML widgets
        recyclerView = findViewById(R.id.recyclerView);
        addDailyWeightButton = findViewById(R.id.dailyWeightButton);
        setGoalButton = findViewById(R.id.setGoalButton);
        quitButton = findViewById(R.id.quitButton);

        weightDataList = new ArrayList<>();
        controller = new DatabaseController(this);

        // Initialize Recycler view
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        loadWeightData();

        // Check SMS permission
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, 1);
        }

        // Set listeners for buttons
        addDailyWeightButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, WeightInputActivity.class);
            startActivityForResult(intent, 1);
        });

        setGoalButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, SetGoalActivity.class);
            startActivityForResult(intent, 2);
        });

        quitButton.setOnClickListener(v -> {
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putFloat("bufferGoalWeight", 0);
            editor.clear();
            editor.apply();

            Intent intent = new Intent(MainActivity.this, LoginActivity.class);
            startActivity(intent);
            finish();
        });
    }

    private void loadWeightData() {
        Cursor cursor = controller.getWeightData(userId);
        weightDataList.clear();
        if (cursor != null && cursor.moveToFirst()) {
            do {
                String date = cursor.getString(cursor.getColumnIndex(SQLiteModule.COLUMN_DATE));
                float currentWeight = cursor.getFloat(cursor.getColumnIndex(SQLiteModule.COLUMN_CURRENT_WEIGHT));
                float goalWeight = cursor.getFloat(cursor.getColumnIndex(SQLiteModule.COLUMN_GOAL_WEIGHT));
                int id = cursor.getInt(cursor.getColumnIndex(SQLiteModule.COLUMN_ID));

                WeightData weightData = new WeightData(date, currentWeight, goalWeight);
                weightData.setId(id);
                weightDataList.add(weightData);
            } while (cursor.moveToNext());
            cursor.close();
        }

        if (weightRecycler == null) {
            weightRecycler = new WeightRecycler(this, weightDataList);
            recyclerView.setAdapter(weightRecycler);
        } else {
            weightRecycler.notifyDataSetChanged(); // Refresh
        }
    }

    private void sendSms(String phoneNumber, String message) {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Toast.makeText(this, "SMS Sent!", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "SMS Permission is required to send notifications", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == 1) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "SMS Permission Granted!", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "SMS Permission Denied! You won't receive SMS notifications.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            if (requestCode == 1) {
                loadWeightData();

                // Check if weight goal was reached
                if (!weightDataList.isEmpty()) {
                    WeightData lastWeight = weightDataList.get(weightDataList.size() - 1);
                    if (lastWeight.getCurrentWeight() <= lastWeight.getGoalWeight()) {
                        sendSms("1234567890", "Congratulations! You have reached your weight goal!");
                    }
                }
            } else if (requestCode == 2) {
                loadWeightData();
            }
        }
    }
}

