package com.zybooks.weightnotwanted;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

// prepares data for the recyler view in main activity
public class WeightRecycler extends RecyclerView.Adapter<WeightRecycler.WeightViewHolder> {

    private Context context;
    private List<WeightData> weightDataList;

    // bring in DB controller
    private DatabaseController controller;

    public WeightRecycler(Context context, List<WeightData> weightDataList) {
        this.context = context;
        this.weightDataList = weightDataList;
        this.controller = new DatabaseController(context);
    }

    @Override
    public WeightViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_weight_data, parent, false);
        return new WeightViewHolder(view);
    }

    @Override
    public void onBindViewHolder(WeightViewHolder holder, int position) {
        WeightData weightData = weightDataList.get(position);
        holder.dateTextView.setText(weightData.getDate());
        holder.currentWeightTextView.setText(String.valueOf(weightData.getCurrentWeight()));
        holder.goalWeightTextView.setText(String.valueOf(weightData.getGoalWeight()));

        holder.deleteButton.setOnClickListener(v -> {
            int weightDataId = weightData.getId();
            deleteWeightData(weightDataId, position);
        });
    }

    @Override
    public int getItemCount() {
        return weightDataList.size();
    }

    private void deleteWeightData(int weightDataId, int position) {
        boolean isDeleted = controller.deleteWeightData(weightDataId);
        if (isDeleted) {
            weightDataList.remove(position);
            notifyItemRemoved(position);
            Toast.makeText(context, "entry deleted.", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(context, "Error.", Toast.LENGTH_SHORT).show();
        }
    }

    // the view class for the recycler.
    public static class WeightViewHolder extends RecyclerView.ViewHolder {

        TextView dateTextView, currentWeightTextView, goalWeightTextView;
        ImageButton deleteButton;

        public WeightViewHolder(View itemView) {
            super(itemView);
            dateTextView = itemView.findViewById(R.id.itemDate);
            currentWeightTextView = itemView.findViewById(R.id.itemWeight);
            goalWeightTextView = itemView.findViewById(R.id.itemGoal);
            deleteButton = itemView.findViewById(R.id.deleteButton);
        }
    }
}
