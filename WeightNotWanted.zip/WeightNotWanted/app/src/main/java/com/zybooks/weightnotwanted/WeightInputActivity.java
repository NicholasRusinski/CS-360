package com.zybooks.weightnotwanted;

import android.app.DatePickerDialog;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Calendar;

public class WeightInputActivity extends AppCompatActivity {
    private EditText weightEditText, dateEditText;
    private Button saveButton, cancelButton;
    private DatabaseController controller;
    private int userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_weight);

        // initialize the widgets from XML file

        weightEditText = findViewById(R.id.weightEditText);
        dateEditText = findViewById(R.id.dateEditText);
        saveButton = findViewById(R.id.saveButton);
        cancelButton = findViewById(R.id.cancelButton);

        // initlizes the DB controller functions
        controller = new DatabaseController(this);

        // Get user session
        SharedPreferences sharedPreferences = getSharedPreferences("UserSession", MODE_PRIVATE);
        userId = sharedPreferences.getInt("userId", -1);  // Example: retrieve from session

        // Set up the date picker for dateEditText
        dateEditText.setClickable(true);
        dateEditText.setFocusable(true);
        dateEditText.setOnClickListener(v -> showDatePickerDialog());


        // button event for saving daily weight
        saveButton.setOnClickListener(v -> {
            String weightString = weightEditText.getText().toString();
            String date = dateEditText.getText().toString();

            if (!weightString.isEmpty() && !date.isEmpty()) {
                float weight = Float.parseFloat(weightString);

                // Check if goal weight is  in buffer or database
                float goalWeight = getGoalWeight();

                if (goalWeight < 1) {
                    Toast.makeText(WeightInputActivity.this, "Please set a goal weight first!", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Add the weight data to the database
                controller.addWeightData(userId, date, weight, goalWeight);
                setResult(RESULT_OK);
                finish();
            } else {
                Toast.makeText(WeightInputActivity.this, "Please fill in both fields!", Toast.LENGTH_SHORT).show();
            }
        });

        // button to reutrn to main
        cancelButton.setOnClickListener(v -> finish());
    }

    // Show the data
    private void showDatePickerDialog() {
        Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);


        DatePickerDialog datePickerDialog = new DatePickerDialog(
                WeightInputActivity.this,
                (view, selectedYear, selectedMonth, selectedDay) -> {

                    String selectedDate = selectedDay + "/" + (selectedMonth + 1) + "/" + selectedYear;
                    dateEditText.setText(selectedDate);
                },
                year, month, day
        );
        datePickerDialog.show();
    }

    // get goal weight


    private float getGoalWeight() {
        SharedPreferences sharedPreferences = getSharedPreferences("UserSession", MODE_PRIVATE);
        float goalWeight = sharedPreferences.getFloat("bufferGoalWeight", -1);

        Log.d("WeightInputActivity", "bufferGoalWeight: " + goalWeight);  // Log the bufferGoalWeight value

        // If the goal weight is still not set (0 or invalid), fetch it from the database
        if (goalWeight <= 0) {
            Log.d("WeightInputActivity", "Goal weight not found in shared preferences, fetching from database...");
            goalWeight = controller.getLastGoalWeight(userId);
            Log.d("WeightInputActivity", "Fetched goal weight from database: " + goalWeight);
        }

        if (goalWeight <= 0) {
            Log.d("WeightInputActivity", "Goal weight is still invalid. Please set a valid goal weight.");
            Toast.makeText(this, "Please set a valid goal weight first!", Toast.LENGTH_SHORT).show();
            return -1;
        }

        Log.d("WeightInputActivity", "Returning goal weight: " + goalWeight);
        return goalWeight;
    }


}



