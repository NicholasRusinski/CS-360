package com.zybooks.weightnotwanted;

// holds weight data before and after database interaction
public class WeightData {
    private String date;
    private float currentWeight;
    private float goalWeight;
    private int id;

    public WeightData(String date, float currentWeight, float goalWeight) {
        this.date = date;
        this.currentWeight = currentWeight;
        this.goalWeight = goalWeight;
    }

    public String getDate() {
        return date;
    }

    public float getCurrentWeight() {
        return currentWeight;
    }

    public float getGoalWeight() {
        return goalWeight;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}

